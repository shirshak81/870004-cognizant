function addToCart(){
    document.getElementById("msg").innerHTML="Item added to Cart Successfully";
    
}

function deleteFromCart(){
    document.getElementById("msg").innerHTML="Item removed from Cart successfully";
    
}